<?php
// ZenoPay Proxy for CPanel Hosting
// This handles CORS issues and provides secure API communication

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ZenoPay API Configuration
$ZENOPAY_API_KEY = 'your_zenopay_api_key_here'; // Replace with your actual API key
$ZENOPAY_BASE_URL = 'https://api.zenopay.co.tz/v1';

function sendResponse($success, $message, $data = null, $httpCode = 200) {
    http_response_code($httpCode);
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit();
}

try {
    // Get the action from the request
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'initiate':
            handlePaymentInitiation();
            break;
        case 'status':
            handleStatusCheck();
            break;
        case 'callback':
            handleCallback();
            break;
        default:
            sendResponse(false, 'Invalid action', null, 400);
    }
} catch (Exception $e) {
    sendResponse(false, 'Server error: ' . $e->getMessage(), null, 500);
}

function handlePaymentInitiation() {
    global $ZENOPAY_API_KEY, $ZENOPAY_BASE_URL;
    
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendResponse(false, 'Method not allowed', null, 405);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        sendResponse(false, 'Invalid JSON payload', null, 400);
    }
    
    // Validate required fields
    $required = ['amount', 'currency', 'buyerEmail', 'buyerName', 'buyerPhone', 'orderId'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            sendResponse(false, "Missing required field: $field", null, 400);
        }
    }
    
    // Normalize phone number for Tanzania
    $phone = normalizePhoneForZenoPay($input['buyerPhone']);
    if (!$phone) {
        sendResponse(false, 'Invalid phone number format. Use Tanzania format: 07XXXXXXXX or +255XXXXXXXXX', null, 400);
    }
    
    // Prepare ZenoPay payload
    $zenoPayload = [
        'amount' => $input['amount'],
        'currency' => $input['currency'],
        'msisdn' => $phone,
        'external_id' => $input['orderId'],
        'callback_url' => getCurrentDomain() . '/zenopay-proxy.php?action=callback'
    ];
    
    // Make request to ZenoPay
    $response = makeZenoPayRequest('/collections/request', $zenoPayload);
    
    if ($response && isset($response['success']) && $response['success']) {
        sendResponse(true, 'Payment initiated successfully', $response);
    } else {
        $errorMsg = $response['message'] ?? 'Payment initiation failed';
        sendResponse(false, $errorMsg, $response, 400);
    }
}

function handleStatusCheck() {
    global $ZENOPAY_API_KEY, $ZENOPAY_BASE_URL;
    
    $orderId = $_GET['orderId'] ?? '';
    if (empty($orderId)) {
        sendResponse(false, 'Missing order ID', null, 400);
    }
    
    // Make request to ZenoPay status endpoint
    $response = makeZenoPayRequest("/collections/status/$orderId", null, 'GET');
    
    if ($response) {
        sendResponse(true, 'Status retrieved successfully', $response);
    } else {
        sendResponse(false, 'Failed to get payment status', null, 400);
    }
}

function handleCallback() {
    // Log the callback for debugging
    $callback_data = file_get_contents('php://input');
    error_log('ZenoPay Callback: ' . $callback_data);
    
    // In a real implementation, you would:
    // 1. Verify the callback signature
    // 2. Update your database
    // 3. Send notifications
    
    sendResponse(true, 'Callback received successfully');
}

function makeZenoPayRequest($endpoint, $data = null, $method = 'POST') {
    global $ZENOPAY_API_KEY, $ZENOPAY_BASE_URL;
    
    $url = $ZENOPAY_BASE_URL . $endpoint;
    
    $curl = curl_init();
    
    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $ZENOPAY_API_KEY,
        'Accept: application/json'
    ];
    
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2
    ]);
    
    if ($data && $method === 'POST') {
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
    }
    
    $response = curl_exec($curl);
    $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $error = curl_error($curl);
    
    curl_close($curl);
    
    if ($error) {
        error_log('CURL Error: ' . $error);
        return null;
    }
    
    return json_decode($response, true);
}

function normalizePhoneForZenoPay($phone) {
    // Remove all non-digit characters
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Handle different formats
    if (preg_match('/^255([0-9]{9})$/', $phone, $matches)) {
        // +255XXXXXXXXX format
        return '0' . $matches[1];
    } elseif (preg_match('/^0([0-9]{9})$/', $phone)) {
        // 0XXXXXXXXX format (already correct)
        return $phone;
    } elseif (preg_match('/^([0-9]{9})$/', $phone, $matches)) {
        // XXXXXXXXX format (missing leading 0)
        return '0' . $matches[1];
    }
    
    return null; // Invalid format
}

function getCurrentDomain() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    return $protocol . '://' . $host;
}
?>